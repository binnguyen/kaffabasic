<?php
namespace Admin\GetSet;
/**
 * Created by PhpStorm.
 * User: MrHung
 * Date: 10/4/14
 * Time: 10:41 AM
 */
use Admin\Entity\Orders;
class getSetOrder extends \Orders {

} 